=== Caldera Forms Run Action ===
Contributors: Desertsnowman, Shelob9
Tags: caldera forms,
Requires at least: 3.9
Tested up to: 4.3
Stable tag: 1.0.0
License: GPLv2+
Donate Link: https://calderawp.com

Trigger an action with your form submission.

== Description ==
A free add-on for [https://calderawp.com/downloads/caldera-forms/](Caldera Forms). A simple, free form processor that lets you do anything with your form data, by specifying an action to run on form submission.

== Installation ==
Install & Activate the plugin through the 'Plugins' menu in WordPress

== Frequently Asked Questions ==
= How Does It Work =
[See this page for more information]( https://calderawp.com/downloads/caldera-form-metabox/)

== Screenshots ==
1. **screenshot1.png** - Processor settings
2. **Set Your Post Types** - Choose which post types to use a metaplate with and where to output the template.


== Changelog ==

= 1.0.0 ( April, 2015 ) =
Initial release to WordPress.org

= 1.0.1 ( August, 2015 =
Add pre/post hooks


== Upgrade Notice ==
still new, so nothing to upgrade.


